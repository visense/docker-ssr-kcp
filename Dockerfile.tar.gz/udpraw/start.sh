#!/bin/sh

/usr/bin/python /shadowsocks/server.py -c "/shadowocks/config.json"
